# React Test

## Intro

Son dos carpetas: `api` y `ui`. La carpeta `api` contiene una aplicacion que devuelve una lista de usuarios. 
La carpeta `ui` es una aplicacion [`create-react-app`](https://github.com/facebookincubator/create-react-app) por defecto.

## La tarea

La tarea es tomar la app `ui` y agregar un componente Modal. Este modal deberá tener un input que hará un request al servicio de la API para autocompletar los nombres de los usuarios 
a medida que el usuario typea en el input.

Para los estilos se puede usar boostrap o similares.

Buscamos un producto que funcione, código claro y testeado.
