# Fake Users API

## Install

`npm i`

## Run

`npm start`

## API

### `/users/[count]` default count is 10.

